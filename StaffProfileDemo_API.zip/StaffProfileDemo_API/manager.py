""" This is the entity, Manager"""
from staff import Staff


class Manager(Staff):

    def __init__(self):
        super().__init__()
        self.__bonus = 0.0

    def get_bonus(self):
        return self.__bonus

    def set_bonus(self, amount):
        self.__bonus = amount

    def get_total_pay(self):
        pay = self.get_contract().get_pay()
        total = pay + self.__bonus
        return total




